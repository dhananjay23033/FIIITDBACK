# Pull Request for Hostelite

## Issue Title : <!-- Enter the issue title here -->

- **Info about the related issue** : <!-- What's the goal of the project -->
- **Name:** <!--Mention Your name-->
- **GitHub ID:** <!-- Mention your GitHub ID -->
- **Idenitfy yourself:** <!-- Mention your role as hacktoberfest 2022 contributor -->


<!-- Mention the following details and these are mandatory -->

Closes: #issue number that will be closed through this PR

### Describe the approach you followed to solve the issue 🤔
### Describe the add-ons or changes you've made 📃
### Don't forget to add screenshots of you work done 📸

Note : The maintainer may reject or suggest changes to the approach or implemenatation of an issue so as to maintain a standard of open-source and this fest.
