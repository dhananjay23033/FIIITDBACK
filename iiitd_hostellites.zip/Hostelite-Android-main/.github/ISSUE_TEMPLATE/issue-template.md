**Points to Note :**

- The issues will be assigned on a first come first serve basis, 1 Issue == 1 PR.
- "Issue Title" and "PR Title should be the same. Include issue number along with it.
- Follow Contributing Guidelines & Code of Conduct before start Contributing.
- This issue is only for 'Hacktoberfest' contributors of 'Hostelite(Android)'.

***********************************************************************
:white_check_mark: **To be Mentioned while taking the issue :**
- Full name : 
- GitHub Profile Link : 
- Request to be assigned an issue :
- Any new feature which you want to add and work on :
- Approach for this issue :
