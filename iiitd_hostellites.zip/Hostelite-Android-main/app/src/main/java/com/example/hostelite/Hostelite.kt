package com.example.hostelite

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Hostelite : Application() {

}