package com.example.hostelite.util

object Constants {
    const val COLLECTION_NAME_USERS = "users"
    const val COLLECTION_NAME_STUDENTS = "users/students"
    const val COLLECTION_NAME_ADMINS = "users/admins"

}